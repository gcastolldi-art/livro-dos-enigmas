import {send} from '../../js/livro.js';
const input=document.getElementById('answer-value');
const button=document.getElementById('submit-answer');
const message=document.getElementById('message');
async function submit(){
 if(button.disabled||button.hidden||input.disabled)return;
 const raw=input.value.trim().replace(',','.');
 const value=Number(raw);
 if(!/^\d+(?:\.\d+)?$/.test(raw)||!Number.isFinite(value)||value<=0){
  message.textContent='Informe uma altura válida em metros, usando apenas o número.';
  input.focus();return;
 }
 await send(String(value));
}
button.addEventListener('click',submit);
input.addEventListener('keydown',event=>{if(event.key==='Enter'){event.preventDefault();submit();}});
